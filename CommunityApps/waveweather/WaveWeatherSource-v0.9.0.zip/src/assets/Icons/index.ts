
export { default as IconPinwheel } from './Icons/IconPinwheel'
export { default as IconWeather } from './Icons/IconWeather'