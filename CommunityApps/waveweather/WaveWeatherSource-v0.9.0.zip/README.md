# Deskthing App Template

This will be where I describe how to use this template. However, I do not have the time nor patience to write yet another README. 

Modify this README.md with your own app details and install instructions so that anyone can install your app into DeskThinghol  ho