
export { default as IconWeather } from './Icons/IconWeather'